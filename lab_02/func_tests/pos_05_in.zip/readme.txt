DES with PCBC is working correctly
